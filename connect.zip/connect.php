<?php

$uri = "mysql://avnadmin:AVNS_U99XIaokXaQkGmJ6ZmF@carteirinha23-carteirinha23.j.aivencloud.com:26656/defaultdb?ssl-mode=REQUIRED";

$fields = parse_url($uri);

$host = "carteirinha23-carteirinha23.j.aivencloud.com";
$port = 26656;
$dbname = "carteirinha23";
$username = "avnadmin";
$password = "AVNS_U99XIaokXaQkGmJ6ZmF";
$sslcert = "ca.pem"; // Caminho do certificado SSL

$conn = new mysqli($host, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$conn->ssl_set(NULL, NULL, $sslcert, NULL, NULL);
if (!$conn->real_connect($host, $username, $password, $dbname, $port)) {
    die("Erro na conexão SSL: " . $conn->connect_error);
}

?>